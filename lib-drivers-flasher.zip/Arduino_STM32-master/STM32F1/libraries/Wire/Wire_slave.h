#error "Something is trying to include Wire_slave.h when Wire.h is already included, they are mutually exclusive"
